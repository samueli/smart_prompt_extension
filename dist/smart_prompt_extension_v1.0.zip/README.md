# Smart Prompt 浏览器扩展

Smart Prompt 是一个强大的浏览器扩展，帮助用户高效管理和优化提示词（Prompts）。无论您是AI开发者、内容创作者，还是日常使用AI工具的用户，这个扩展都能让您的工作流程更加顺畅。

## ✨ 主要特性

- 🔄 提示词保存与管理
- 🎯 智能提示词优化
- 🌍 多语言支持（中文、英文）
- ⚙️ 可配置的API设置
- 💾 本地数据存储
- 🔒 安全的数据处理

## 🛠️ 技术栈

- Chrome Extension Manifest V3
- Chrome Storage API
- Chrome i18n 国际化支持
- JavaScript ES6+

## 📦 安装方法

### 开发者安装
1. 克隆仓库到本地：
```bash
git clone [repository-url]
cd smart_prompt_extension
```

2. 安装依赖：
```bash
npm install --verbose
```

3. 构建项目：
```bash
npm run build
```

4. 在Chrome浏览器中加载扩展：
   - 打开 Chrome 浏览器，访问 `chrome://extensions/`
   - 开启右上角的"开发者模式"
   - 点击"加载已解压的扩展程序"
   - 选择项目中的 `dist` 目录

### 用户安装
- 从 Chrome 网上应用店安装（即将上线）

## 🚀 使用指南

### 基本使用
1. 点击浏览器工具栏中的扩展图标
2. 在弹出窗口中可以：
   - 保存当前使用的提示词
   - 优化已保存的提示词
   - 管理提示词集合

### 设置选项
1. 右键点击扩展图标，选择"选项"
2. 在设置页面可以：
   - 切换界面语言（中文/英文）
   - 配置 API Token
   - 自定义其他设置

## 📂 项目结构

```
smart_prompt_extension/
├── _locales/          # 多语言支持文件
│   ├── en/           # 英文语言包
│   └── zh/           # 中文语言包
├── assets/           # 静态资源文件
├── js/              # JavaScript 源代码
├── popup/           # 扩展弹出窗口相关文件
├── options/         # 设置页面相关文件
├── background.js    # 后台服务脚本
├── manifest.json    # 扩展配置文件
└── dist/            # 构建输出目录
```

## 🔧 开发指南

### 本地开发
1. 修改代码后执行构建：
```bash
npm run build
```

2. 在Chrome扩展页面点击刷新按钮更新扩展

### 多语言开发
- 在 `_locales` 目录下相应的语言文件中添加新的文本键值对
- 使用 `chrome.i18n.getMessage()` 方法获取翻译文本

## 📝 注意事项

- 请确保在使用API相关功能前配置正确的API Token
- 所有数据均存储在本地，注意定期备份重要的提示词
- 扩展会自动检测浏览器语言并设置对应的界面语言

## 🤝 贡献指南

欢迎提交 Issue 和 Pull Request 来帮助改进这个项目。在提交PR前，请确保：

1. 代码符合项目的编码规范
2. 所有的改动都经过充分测试
3. 更新相关文档

## 📄 许可证

[MIT License](LICENSE)

## 🙋‍♂️ 支持与反馈

如果您在使用过程中遇到任何问题，或有任何建议，请：

- 提交 Issue
- 发送邮件至：[support-email]
- 访问我们的支持页面：[support-url]
